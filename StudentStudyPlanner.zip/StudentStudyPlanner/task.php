<?php
session_start();
$host = 'localhost';
$db = 'study_planner';
$user = 'root';
$pass = ''; // Update with your MySQL password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$task = null;

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['id'], $user_id]);
    $task = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $due_date = $_POST['due_date'];
    $priority = $_POST['priority'];

    if (isset($_GET['id'])) {
        // Update task
        $stmt = $pdo->prepare("UPDATE tasks SET title = ?, description = ?, due_date = ?, priority = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$title, $description, $due_date, $priority, $_GET['id'], $user_id]);
    } else {
        // Add task
        $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, description, due_date, priority) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $title, $description, $due_date, $priority]);
    }
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($task) ? 'Edit Task' : 'Add Task'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h2><?php echo isset($task) ? 'Edit Task' : 'Add Task'; ?></h2>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Subject </label>
                <input type="text" name="title" class="form-control" value="<?php echo isset($task) ? htmlspecialchars($task['title']) : ''; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"><?php echo isset($task) ? htmlspecialchars($task['description']) : ''; ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Due Date</label>
                <input type="datetime-local" name="due_date" class="form-control" value="<?php echo isset($task) ? $task['due_date'] : ''; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Priority</label>
                <select name="priority" class="form-select">
                    <option value="low" <?php echo isset($task) && $task['priority'] == 'low' ? 'selected' : ''; ?>>Low</option>
                    <option value="medium" <?php echo isset($task) && $task['priority'] == 'medium' ? 'selected' : ''; ?>>Medium</option>
                    <option value="high" <?php echo isset($task) && $task['priority'] == 'high' ? 'selected' : ''; ?>>High</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo isset($task) ? 'Update Task' : 'Add Task'; ?></button>
            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>