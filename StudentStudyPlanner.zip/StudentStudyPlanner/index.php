<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Study Planner</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <!-- Homepage Widget -->
        <div class="study-widget card shadow-sm">
            <div class="card-header text-center bg-primary text-black">
                <h3>Welcome to Your Study Planner</h3>
            </div>
            <div class="card-body text-center">
                <p class="lead">Organize your study schedule, track tasks, and ace your goals!</p>
                <p class="quote">"The secret of getting ahead is getting started." – Lemon Shun</p>
                <div class="widget-actions mt-4">
                    <a href="login.php" class="btn btn-primary btn-lg">Login</a>
                    <a href="register.php" class="btn btn-outline-secondary btn-lg">Register</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>